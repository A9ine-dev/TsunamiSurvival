# Tsunami Survival — experimental first test

**Target:** Minecraft Java 1.21.11 · Fabric · Java 21 · intended for Zalith Launcher 1.

## What this prototype does
- `/tsunami start` starts a wave in the direction the player is facing.
- `/tsunami start 24` starts a taller wave (height range 6–30).
- `/tsunami stop` stops the advancing event. Water already placed remains.
- `/tsunami help` lists commands.
- The wave advances as a broad, rounded, undulating front.
- Splash, bubble and mist particles appear at obstacles and along the crest.
- Solid blocks are not intentionally broken or replaced; water fills air and replaceable spaces.

## Important limitations
This is a **first-test approximation**, not a physically simulated ocean. It uses ordinary Minecraft water blocks and particles. It does not yet have a custom animated water mesh, curling fluid surface, or physically accurate fluid dynamics. Water placement changes the world and may flood interiors through openings. Test in a new creative world or a backup. Stopping the event does not remove water already placed.

## Build a playable JAR
This workspace could not compile the project because Gradle is not installed and outbound network access is unavailable. A GitHub Actions workflow is included at `.github/workflows/build.yml` to build it in a cloud runner:

1. Create a GitHub repository and upload the contents of this folder (not the ZIP file itself).
2. Open the repository's **Actions** tab and run **Build Tsunami Survival** (or push to `main`).
3. When the workflow succeeds, open its run and download the `tsunami-survival-1.21.11` artifact.
4. Extract the artifact ZIP; place the mod JAR in the `mods` folder of a Minecraft **1.21.11 Fabric** instance with Fabric API installed.
5. Launch with Java 21. In Zalith, ensure the instance is Fabric 1.21.11, not vanilla 1.21.11.

The workflow has been provided but has **not itself been run** here. The resulting JAR must still be tested in Zalith; compatibility is not claimed until that test succeeds.
