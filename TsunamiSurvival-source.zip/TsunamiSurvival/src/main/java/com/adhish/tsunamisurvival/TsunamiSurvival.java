package com.adhish.tsunamisurvival;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.phys.Vec3;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class TsunamiSurvival implements ModInitializer {
    private static final Map<UUID, Wave> WAVES = new HashMap<>();
    private static final int HALF_WIDTH = 24;
    private static final int MAX_HEIGHT = 18;
    private static final int ADVANCE_EVERY_TICKS = 3;

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("tsunami")
                .then(Commands.literal("start")
                    .then(Commands.argument("height", IntegerArgumentType.integer(6, 30))
                        .executes(ctx -> start(ctx.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(ctx, "height"))))
                    .executes(ctx -> start(ctx.getSource().getPlayerOrException(), MAX_HEIGHT)))
                .then(Commands.literal("stop").executes(ctx -> stop(ctx.getSource().getPlayerOrException())))
                .then(Commands.literal("help").executes(ctx -> {
                    ctx.getSource().sendSuccess(() -> Component.literal("/tsunami start [height 6-30] | /tsunami stop. Warning: experimental block-changing event; back up your world."), false);
                    return 1;
                }))));
        ServerTickEvents.END_SERVER_TICK.register(this::tick);
    }

    private static int start(ServerPlayer player, int height) {
        Vec3 look = player.getLookAngle();
        Direction direction = Direction.fromYRot(Math.toDegrees(Math.atan2(-look.x, look.z)));
        // Start offshore, in the direction the player is facing.
        BlockPos origin = player.blockPosition().relative(direction, 42);
        Wave wave = new Wave(player.serverLevel(), origin, direction, Math.min(height, 30));
        WAVES.put(player.getUUID(), wave);
        player.sendSystemMessage(Component.literal("§bTSUNAMI WARNING! §fA huge wave is approaching. Get to high ground!"));
        return 1;
    }

    private static int stop(ServerPlayer player) {
        WAVES.remove(player.getUUID());
        player.sendSystemMessage(Component.literal("Tsunami event stopped. Water already placed will remain.") );
        return 1;
    }

    private void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Wave>> it = WAVES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Wave> entry = it.next();
            Wave wave = entry.getValue();
            if (++wave.ticks % ADVANCE_EVERY_TICKS != 0) continue;
            if (!wave.advance()) {
                ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
                if (player != null) player.sendSystemMessage(Component.literal("§bThe tsunami has passed. Water remains in the flooded area."));
                it.remove();
            }
        }
    }

    private static final class Wave {
        final ServerLevel level;
        final Direction travel;
        final Direction across;
        final int height;
        BlockPos front;
        int ticks;
        int steps;

        Wave(ServerLevel level, BlockPos start, Direction travel, int height) {
            this.level = level; this.front = start; this.travel = travel;
            this.across = travel.getClockWise(); this.height = height;
        }

        boolean advance() {
            if (steps++ > 150) return false;
            // A curved crest: tallest in the middle, tapering towards both ends.
            for (int lateral = -HALF_WIDTH; lateral <= HALF_WIDTH; lateral++) {
                double edge = 1.0 - (Math.abs(lateral) / (double)(HALF_WIDTH + 1));
                // Rounded shoulders and a moving pulse make the crest less like a flat wall.
                double shoulder = Math.pow(Math.max(0.0, edge), 0.62);
                double rollingPulse = 0.88 + 0.12 * Math.sin(steps * 0.16 + lateral * 0.075);
                int crest = (int)Math.round(height * (0.22 + 0.78 * shoulder) * rollingPulse);
                int wobble = (int)Math.round(Math.sin((steps * 0.31) + lateral * 0.17) * 1.4);
                int columnHeight = Math.max(2, crest + wobble);
                BlockPos column = front.relative(across, lateral);
                if (!level.hasChunkAt(column)) continue;
                int ground = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING, column.getX(), column.getZ());
                int top = Math.min(level.getMaxBuildHeight() - 2, ground + columnHeight);
                // Fill a moving wall of water. Solid structures are never broken or replaced.
                // When the advancing water meets a solid block, throw up a visible spray effect.
                boolean hitSurface = false;
                BlockPos hitPosition = null;
                for (int y = ground; y <= top; y++) {
                    BlockPos p = new BlockPos(column.getX(), y, column.getZ());
                    BlockState old = level.getBlockState(p);
                    if (old.isAir() || old.canBeReplaced() || old.is(Blocks.SHORT_GRASS) || old.is(Blocks.TALL_GRASS)
                            || old.is(Blocks.FERN) || old.is(Blocks.LARGE_FERN) || old.is(Blocks.SNOW)) {
                        level.setBlock(p, Blocks.WATER.defaultBlockState(), Block.UPDATE_ALL);
                    } else if (old.blocksMotion() && old.getFluidState().isEmpty()) {
                        // A solid, non-fluid surface is an obstacle for the wave.
                        hitSurface = true;
                        hitPosition = p;
                    }
                }
                if (hitSurface && hitPosition != null && steps % 2 == 0 && lateral % 3 == 0) {
                    double sx = hitPosition.getX() + 0.5 + travel.getStepX() * 0.55;
                    double sy = hitPosition.getY() + 0.8;
                    double sz = hitPosition.getZ() + 0.5 + travel.getStepZ() * 0.55;
                    level.sendParticles(ParticleTypes.SPLASH, sx, sy, sz, 18, 0.65, 0.55, 0.65, 0.18);
                    level.sendParticles(ParticleTypes.BUBBLE, sx, sy - 0.25, sz, 7, 0.45, 0.35, 0.45, 0.08);
                }
                // A thin spray along the moving crest helps make the wave visibly roll forward.
                if (steps % 2 == 0 && lateral % 3 == 0) {
                    double crestX = column.getX() + 0.5;
                    double crestZ = column.getZ() + 0.5;
                    level.sendParticles(ParticleTypes.SPLASH, crestX, top + 0.15, crestZ,
                            5, 0.55, 0.22, 0.55, 0.11);
                    // Fine mist above the crest helps sell the scale of the incoming wave.
                    level.sendParticles(ParticleTypes.CLOUD, crestX, top + 0.65, crestZ,
                            2, 0.38, 0.22, 0.38, 0.015);
                }
                // Leave a continuous shallow flooded wake behind the moving crest.
                for (int depth = 1; depth <= 2; depth++) {
                    BlockPos wake = column.relative(travel.getOpposite(), depth);
                    if (level.getBlockState(wake).isAir()) {
                        level.setBlock(wake, Blocks.WATER.defaultBlockState(), Block.UPDATE_ALL);
                    }
                }
            }
            front = front.relative(travel, 2);
            return true;
        }
    }
}
